### WhatsApp MD user bot

### Setup

1. Click [SCAN](https://levanter.up.railway.app/md) and scan QR through Whatsapp Linked Devices Option in Your whatsapp App.
2. You will get a session id in whatsapp, copy id only.
3. If You don't have a account in [Heroku](https://signup.heroku.com/), Create a account.
4. Click [FORK](https://github.com/lyfe00011/whatsapp-bot-md/fork)
5. Now [DEPLOY](https://levanter.up.railway.app/dmd)

   <a href="https://chat.whatsapp.com/Jl6U29pBwmWLG3OOOfdPPt"><img alt="WhatsApp" src="https://img.shields.io/badge/-Whatsapp%20Group-lightgrey?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>

### Thanks To

- [Yusuf Usta](https://github.com/Quiec) for [WhatsAsena](https://github.com/yusufusta/WhatsAsena)
- [@adiwajshing](https://github.com/adiwajshing) for [Baileys](https://github.com/adiwajshing/Baileys)
